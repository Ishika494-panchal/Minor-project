function ProfessionalTemplate({ data }) {
  return (
    <div className="rounded-2xl border border-slate-300 bg-white p-6 shadow-sm">
      <header className="border-b border-slate-200 pb-3">
        <h1 className="text-2xl font-bold text-slate-900">{data.name || "Your Name"}</h1>
        <p className="mt-1 text-sm text-slate-600">
          {data.email || "email@example.com"} | {data.phone || "+91-XXXXXXXXXX"} | {data.linkedIn || "linkedin.com/in/username"}
        </p>
      </header>

      <main className="mt-4 grid gap-4">
        <section>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-800">Summary</h3>
          <p className="mt-1 whitespace-pre-line text-sm text-slate-700">{data.summary || "-"}</p>
        </section>

        <section>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-800">Skills</h3>
          <p className="mt-1 text-sm text-slate-700">{(data.skills || []).join(", ") || "-"}</p>
        </section>

        <section>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-800">Experience</h3>
          <ul className="mt-1 list-disc pl-5 text-sm text-slate-700">
            {(data.experience || []).length ? data.experience.map((item, idx) => <li key={`exp-${idx}`}>{item}</li>) : <li>-</li>}
          </ul>
        </section>

        <section>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-800">Projects</h3>
          <ul className="mt-1 list-disc pl-5 text-sm text-slate-700">
            {(data.projects || []).length ? data.projects.map((item, idx) => <li key={`proj-${idx}`}>{item}</li>) : <li>-</li>}
          </ul>
        </section>

        <section>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-800">Education</h3>
          <ul className="mt-1 list-disc pl-5 text-sm text-slate-700">
            {(data.education || []).length ? data.education.map((item, idx) => <li key={`edu-${idx}`}>{item}</li>) : <li>-</li>}
          </ul>
        </section>

        <section>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-800">Certifications</h3>
          <ul className="mt-1 list-disc pl-5 text-sm text-slate-700">
            {(data.certifications || []).length ? data.certifications.map((item, idx) => <li key={`cert-${idx}`}>{item}</li>) : <li>-</li>}
          </ul>
        </section>
      </main>
    </div>
  );
}

export default ProfessionalTemplate;
