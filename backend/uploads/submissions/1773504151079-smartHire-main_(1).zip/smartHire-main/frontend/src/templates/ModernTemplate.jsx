function ModernTemplate({ data }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
      <h1 className="text-3xl font-bold text-slate-900">{data.name || "Your Name"}</h1>
      <p className="mt-1 text-sm text-slate-600">
        {data.email || "email@example.com"} | {data.phone || "+91-XXXXXXXXXX"} | {data.linkedIn || "linkedin.com/in/username"}
      </p>

      <section className="mt-5">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-blue-700">Summary</h3>
        <p className="mt-1 whitespace-pre-line text-sm text-slate-700">{data.summary || "-"}</p>
      </section>

      <section className="mt-4">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-blue-700">Skills</h3>
        <div className="mt-2 flex flex-wrap gap-2">
          {(data.skills || []).length ? (
            data.skills.map((skill) => (
              <span key={skill} className="rounded-full bg-blue-50 px-2.5 py-1 text-xs text-blue-700">
                {skill}
              </span>
            ))
          ) : (
            <span className="text-sm text-slate-500">-</span>
          )}
        </div>
      </section>

      <section className="mt-4">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-blue-700">Experience</h3>
        <ul className="mt-1 list-disc space-y-1 pl-5 text-sm text-slate-700">
          {(data.experience || []).length ? data.experience.map((item, idx) => <li key={`${item}-${idx}`}>{item}</li>) : <li>-</li>}
        </ul>
      </section>

      <section className="mt-4">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-blue-700">Projects</h3>
        <ul className="mt-1 list-disc space-y-1 pl-5 text-sm text-slate-700">
          {(data.projects || []).length ? data.projects.map((item, idx) => <li key={`${item}-${idx}`}>{item}</li>) : <li>-</li>}
        </ul>
      </section>

      <section className="mt-4">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-blue-700">Education</h3>
        <ul className="mt-1 list-disc space-y-1 pl-5 text-sm text-slate-700">
          {(data.education || []).length ? data.education.map((item, idx) => <li key={`${item}-${idx}`}>{item}</li>) : <li>-</li>}
        </ul>
      </section>

      <section className="mt-4">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-blue-700">Certifications</h3>
        <ul className="mt-1 list-disc space-y-1 pl-5 text-sm text-slate-700">
          {(data.certifications || []).length ? data.certifications.map((item, idx) => <li key={`${item}-${idx}`}>{item}</li>) : <li>-</li>}
        </ul>
      </section>
    </div>
  );
}

export default ModernTemplate;
