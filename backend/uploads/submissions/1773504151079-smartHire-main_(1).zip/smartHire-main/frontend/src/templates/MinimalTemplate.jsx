function MinimalTemplate({ data }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-6">
      <h1 className="text-2xl font-semibold text-slate-900">{data.name || "Your Name"}</h1>
      <p className="text-sm text-slate-600">
        {data.email || "email@example.com"} | {data.phone || "+91-XXXXXXXXXX"} | {data.linkedIn || "linkedin.com/in/username"}
      </p>
      <hr className="my-4 border-slate-200" />

      {[
        ["Summary", [data.summary || "-"]],
        ["Skills", data.skills || []],
        ["Experience", data.experience || []],
        ["Projects", data.projects || []],
        ["Education", data.education || []],
        ["Certifications", data.certifications || []],
      ].map(([title, items]) => (
        <section className="mb-4" key={title}>
          <h3 className="text-sm font-semibold text-slate-800">{title}</h3>
          <ul className="mt-1 list-disc pl-5 text-sm text-slate-700">
            {items.length ? items.map((item, idx) => <li key={`${title}-${idx}`}>{item}</li>) : <li>-</li>}
          </ul>
        </section>
      ))}
    </div>
  );
}

export default MinimalTemplate;
