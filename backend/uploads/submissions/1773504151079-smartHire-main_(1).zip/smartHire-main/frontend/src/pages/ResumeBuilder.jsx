import { useMemo, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import html2pdf from "html2pdf.js";
import { FileDown, PencilLine, SearchCheck } from "lucide-react";
import { JOB_ROLES } from "../data/jobRoles";
import ModernTemplate from "../templates/ModernTemplate";
import MinimalTemplate from "../templates/MinimalTemplate";
import ProfessionalTemplate from "../templates/ProfessionalTemplate";

const templates = {
  modern: ModernTemplate,
  minimal: MinimalTemplate,
  professional: ProfessionalTemplate,
};

const splitItems = (value = "") =>
  value
    .split(/\n|,/)
    .map((item) => item.trim())
    .filter(Boolean);

const escapeHtml = (value = "") =>
  value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");

const buildPdfTemplateHtml = (data) => `
  <div style="font-family: Arial, sans-serif; color: #111827; background: #ffffff; padding: 28px; width: 760px;">
    <h1 style="font-size: 28px; margin: 0 0 10px; color: #0f172a;">${escapeHtml(data.name || "Your Name")}</h1>
    <p style="font-size: 12px; color: #475569; margin: 0 0 16px;">
      ${escapeHtml(data.email || "email@example.com")} | ${escapeHtml(data.phone || "+91-XXXXXXXXXX")} | ${escapeHtml(data.linkedIn || "linkedin.com/in/username")}
    </p>

    <h3 style="font-size: 12px; text-transform: uppercase; color: #334155; margin: 0 0 6px;">Summary</h3>
    <p style="font-size: 13px; margin: 0 0 12px; line-height: 1.6;">${escapeHtml(data.summary || "-").replaceAll("\n", "<br/>")}</p>

    <h3 style="font-size: 12px; text-transform: uppercase; color: #334155; margin: 0 0 6px;">Skills</h3>
    <p style="font-size: 13px; margin: 0 0 12px; line-height: 1.6;">${(data.skills || []).map(escapeHtml).join(", ") || "-"}</p>

    <h3 style="font-size: 12px; text-transform: uppercase; color: #334155; margin: 0 0 6px;">Experience</h3>
    <ul style="margin: 0 0 12px 16px; padding: 0;">
      ${(data.experience || []).length ? data.experience.map((item) => `<li style="font-size: 13px; margin: 0 0 4px;">${escapeHtml(item)}</li>`).join("") : '<li style="font-size: 13px;">-</li>'}
    </ul>

    <h3 style="font-size: 12px; text-transform: uppercase; color: #334155; margin: 0 0 6px;">Projects</h3>
    <ul style="margin: 0 0 12px 16px; padding: 0;">
      ${(data.projects || []).length ? data.projects.map((item) => `<li style="font-size: 13px; margin: 0 0 4px;">${escapeHtml(item)}</li>`).join("") : '<li style="font-size: 13px;">-</li>'}
    </ul>

    <h3 style="font-size: 12px; text-transform: uppercase; color: #334155; margin: 0 0 6px;">Education</h3>
    <ul style="margin: 0 0 12px 16px; padding: 0;">
      ${(data.education || []).length ? data.education.map((item) => `<li style="font-size: 13px; margin: 0 0 4px;">${escapeHtml(item)}</li>`).join("") : '<li style="font-size: 13px;">-</li>'}
    </ul>

    <h3 style="font-size: 12px; text-transform: uppercase; color: #334155; margin: 0 0 6px;">Certifications</h3>
    <ul style="margin: 0 0 12px 16px; padding: 0;">
      ${(data.certifications || []).length ? data.certifications.map((item) => `<li style="font-size: 13px; margin: 0 0 4px;">${escapeHtml(item)}</li>`).join("") : '<li style="font-size: 13px;">-</li>'}
    </ul>
  </div>
`;

function ResumeBuilder() {
  const [searchParams] = useSearchParams();
  const templateKey = (searchParams.get("template") || "modern").toLowerCase();
  const TemplateComponent = templates[templateKey] || ModernTemplate;
  const previewRef = useRef(null);

  const [resumeData, setResumeData] = useState({
    name: "",
    email: "",
    phone: "",
    linkedIn: "",
    summary: "",
    skillsText: "",
    experienceText: "",
    projectsText: "",
    educationText: "",
    certificationsText: "",
  });
  const [selectedRole, setSelectedRole] = useState("");
  const [analysis, setAnalysis] = useState(null);
  const [isPreview, setIsPreview] = useState(false);
  const [downloadError, setDownloadError] = useState("");

  const normalizedData = useMemo(
    () => ({
      name: resumeData.name,
      email: resumeData.email,
      phone: resumeData.phone,
      linkedIn: resumeData.linkedIn,
      summary: resumeData.summary,
      skills: splitItems(resumeData.skillsText),
      experience: splitItems(resumeData.experienceText),
      projects: splitItems(resumeData.projectsText),
      education: splitItems(resumeData.educationText),
      certifications: splitItems(resumeData.certificationsText),
    }),
    [resumeData]
  );

  const handleAnalyzeAts = () => {
    const role = JOB_ROLES.find((item) => item.job_role === selectedRole);
    if (!role) return;
    const roleSkills = role.skills.map((item) => item.toLowerCase());
    const resumeSkills = normalizedData.skills.map((item) => item.toLowerCase());
    const allRequired = [...new Set([...roleSkills])];

    const matched = allRequired.filter((required) =>
      resumeSkills.some((skill) => skill.includes(required) || required.includes(skill))
    );
    const missing = allRequired.filter(
      (required) => !resumeSkills.some((skill) => skill.includes(required) || required.includes(skill))
    );
    const score = allRequired.length ? Math.round((matched.length / allRequired.length) * 100) : 0;

    const sectionSuggestions = {
      skills: missing.map((item) => `Add skill: ${item}`),
      summary:
        (normalizedData.summary || "").trim().length < 90
          ? ["Expand summary with role keywords and measurable impact."]
          : [],
      experience:
        normalizedData.experience.length < 2
          ? ["Add at least 2 experience points with action + impact (e.g. improved performance by 20%)."]
          : [],
      projects:
        normalizedData.projects.length < 2
          ? ["Include 2+ relevant projects with stack, role, and outcome."]
          : [],
      education:
        normalizedData.education.length < 1
          ? ["Add degree/college details and graduation timeline."]
          : [],
      certifications:
        normalizedData.certifications.length < 1
          ? ["Add role-relevant certifications to strengthen ATS profile."]
          : [],
      contact: [
        ...(!normalizedData.email ? ["Add professional email address."] : []),
        ...(!normalizedData.phone ? ["Add contact phone number."] : []),
        ...(!normalizedData.linkedIn ? ["Add LinkedIn profile URL."] : []),
      ],
    };

    setAnalysis({
      score,
      missing,
      matched,
      sectionSuggestions,
    });
  };

  const downloadPDF = async () => {
    setDownloadError("");
    let printContainer = null;
    try {
      printContainer = window.document.createElement("div");
      printContainer.style.position = "fixed";
      printContainer.style.left = "-99999px";
      printContainer.style.top = "0";
      printContainer.innerHTML = buildPdfTemplateHtml(normalizedData);
      window.document.body.appendChild(printContainer);

      await html2pdf()
        .set({
          margin: 8,
          filename: `${(normalizedData.name || "resume").replace(/\s+/g, "_")}.pdf`,
          html2canvas: { scale: 2, useCORS: true, backgroundColor: "#ffffff" },
          jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
        })
        .from(printContainer.firstElementChild)
        .save();
    } catch {
      setDownloadError("Unable to export styled PDF in this browser right now. Try again after refresh.");
    } finally {
      if (printContainer && window.document.body.contains(printContainer)) {
        window.document.body.removeChild(printContainer);
      }
    }
  };

  const updateField = (field) => (event) => {
    setResumeData((prev) => ({ ...prev, [field]: event.target.value }));
  };

  return (
    <div className="grid gap-5 lg:grid-cols-1 xl:grid-cols-[1fr_1fr]">
      {!isPreview && (
        <section className="space-y-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <h3 className="text-lg font-semibold text-slate-800">Resume Form</h3>
          <div className="grid gap-3">
            <input value={resumeData.name} onChange={updateField("name")} placeholder="Name" className="rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none" />
            <input value={resumeData.email} onChange={updateField("email")} placeholder="Email" className="rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none" />
            <input value={resumeData.phone} onChange={updateField("phone")} placeholder="Phone" className="rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none" />
            <input value={resumeData.linkedIn} onChange={updateField("linkedIn")} placeholder="LinkedIn URL" className="rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none" />
            <textarea value={resumeData.summary} onChange={updateField("summary")} rows={3} placeholder="Summary" className="rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none" />
            <textarea value={resumeData.skillsText} onChange={updateField("skillsText")} rows={3} placeholder="Skills (comma/new line separated)" className="rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none" />
            <textarea value={resumeData.experienceText} onChange={updateField("experienceText")} rows={3} placeholder="Experience (comma/new line separated)" className="rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none" />
            <textarea value={resumeData.projectsText} onChange={updateField("projectsText")} rows={3} placeholder="Projects (comma/new line separated)" className="rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none" />
            <textarea value={resumeData.educationText} onChange={updateField("educationText")} rows={3} placeholder="Education (comma/new line separated)" className="rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none" />
            <textarea value={resumeData.certificationsText} onChange={updateField("certificationsText")} rows={3} placeholder="Certifications (comma/new line separated)" className="rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none" />
          </div>
          <button type="button" onClick={() => setIsPreview(true)} className="rounded-lg bg-[#1e3a8a] px-4 py-2 text-sm font-medium text-white">
            Preview Resume
          </button>
        </section>
      )}

      <section className="space-y-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <button type="button" onClick={() => setIsPreview(false)} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-700">
              <PencilLine size={15} />
              Edit Resume
            </button>
            <button type="button" onClick={downloadPDF} className="inline-flex items-center gap-1 rounded-lg bg-[#1e3a8a] px-3 py-1.5 text-sm text-white">
              <FileDown size={15} />
              Download Resume
            </button>
          </div>
        {!!downloadError && <p className="mb-3 text-sm text-red-600">{downloadError}</p>}
          <div ref={previewRef} id="resume-preview">
            <TemplateComponent data={normalizedData} />
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <h3 className="text-lg font-semibold text-slate-800">Analyze ATS</h3>
          <select
            value={selectedRole}
            onChange={(event) => setSelectedRole(event.target.value)}
            className="mt-2 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
          >
            <option value="">Select Job Role</option>
            {JOB_ROLES.map((role) => (
              <option key={role.job_role} value={role.job_role}>
                {role.job_role}
              </option>
            ))}
          </select>
          <button type="button" onClick={handleAnalyzeAts} className="mt-3 inline-flex items-center gap-2 rounded-lg bg-[#0f766e] px-4 py-2 text-sm font-medium text-white">
            <SearchCheck size={16} />
            Analyze ATS Score
          </button>

          {analysis && (
            <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50 p-4">
              <p className="text-lg font-semibold text-emerald-800">Score: {analysis.score}%</p>
              <p className="mt-2 text-xs font-semibold uppercase text-slate-600">Missing Skills</p>
              <div className="mt-1 flex flex-wrap gap-2">
                {analysis.missing.length ? (
                  analysis.missing.map((skill) => (
                    <span key={skill} className="rounded-full bg-white px-2 py-1 text-xs text-red-600">
                      {skill}
                    </span>
                  ))
                ) : (
                  <span className="text-sm text-emerald-700">No major missing skills.</span>
                )}
              </div>

              <div className="mt-4 rounded-lg border border-white bg-white p-3">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-600">Suggestions for all sections</p>
                <div className="mt-2 grid gap-2 md:grid-cols-2">
                  {Object.entries(analysis.sectionSuggestions || {}).map(([section, suggestions]) => (
                    <div key={section} className="rounded-lg border border-slate-200 p-2">
                      <p className="text-xs font-semibold capitalize text-slate-700">{section}</p>
                      {suggestions.length ? (
                        <ul className="mt-1 list-disc space-y-1 pl-4 text-xs text-slate-600">
                          {suggestions.map((item, idx) => (
                            <li key={`${section}-${idx}`}>{item}</li>
                          ))}
                        </ul>
                      ) : (
                        <p className="mt-1 text-xs text-emerald-700">Looks good.</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

export default ResumeBuilder;
