import { useNavigate } from "react-router-dom";

const TEMPLATES = [
  {
    id: "modern",
    label: "Modern",
    subtitle: "Clean with skill tags",
    preview: "bg-gradient-to-br from-blue-100 via-sky-50 to-white",
    accent: "bg-blue-500",
  },
  {
    id: "minimal",
    label: "Minimal",
    subtitle: "Simple and ATS-friendly",
    preview: "bg-gradient-to-br from-slate-100 via-white to-slate-50",
    accent: "bg-slate-500",
  },
  {
    id: "professional",
    label: "Professional",
    subtitle: "Formal corporate style",
    preview: "bg-gradient-to-br from-indigo-100 via-slate-50 to-white",
    accent: "bg-indigo-600",
  },
];

function TemplateSelection() {
  const navigate = useNavigate();

  return (
    <div className="relative min-h-[calc(100vh-7rem)] overflow-hidden rounded-2xl border border-blue-100 bg-gradient-to-br from-slate-50 via-white to-blue-50 p-4 shadow-sm sm:p-6">
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-blue-100/20 via-transparent to-cyan-100/20" />
      <div className="pointer-events-none absolute -left-28 top-10 h-72 w-72 rounded-full bg-blue-200/35 blur-3xl" />
      <div className="pointer-events-none absolute -right-20 bottom-0 h-72 w-72 rounded-full bg-cyan-200/35 blur-3xl" />

      <div className="relative">
        <h2 className="text-2xl font-semibold text-[#1d2b5d]">Choose Your Resume Template</h2>
        <p className="mt-1 text-sm text-slate-600">Pick one template to continue to resume builder.</p>

        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {TEMPLATES.map((template) => (
            <button
              key={template.id}
              type="button"
              onClick={() => navigate(`/resume-builder?template=${template.id}`)}
              className="group rounded-2xl border border-blue-100 bg-white/80 p-5 text-left shadow-sm backdrop-blur transition hover:-translate-y-1 hover:border-blue-300 hover:shadow-md"
            >
              <div className={`h-24 rounded-xl border border-blue-200 p-2 ${template.preview}`}>
                <div className="h-full rounded-lg border border-white/70 bg-white/70 p-2">
                  <div className="flex items-center gap-2">
                    <span className={`h-2.5 w-2.5 rounded-full ${template.accent}`} />
                    <div className="h-2 w-24 rounded bg-slate-200" />
                  </div>
                  <div className="mt-2 space-y-1.5">
                    <div className="h-2 w-full rounded bg-slate-200" />
                    <div className="h-2 w-[85%] rounded bg-slate-200" />
                    <div className="h-2 w-[70%] rounded bg-slate-200" />
                  </div>
                </div>
              </div>
              <p className="mt-4 text-lg font-semibold text-slate-800">{template.label}</p>
              <p className="mt-1 text-sm text-slate-600">{template.subtitle}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export default TemplateSelection;
