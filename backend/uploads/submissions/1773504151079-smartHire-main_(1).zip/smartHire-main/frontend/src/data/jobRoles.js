export const JOB_ROLES = [
  {
    job_role: "Frontend Developer",
    skills: ["HTML", "CSS", "JavaScript", "React", "Git", "Responsive Design", "REST APIs", "TypeScript"],
  },
  {
    job_role: "Backend Developer",
    skills: ["Node.js", "Express.js", "Python", "Django", "REST APIs", "Database Design", "Authentication", "Git"],
  },
  {
    job_role: "Full Stack Developer",
    skills: ["HTML", "CSS", "JavaScript", "React", "Node.js", "Express.js", "MongoDB", "REST APIs", "Git"],
  },
  {
    job_role: "Data Scientist",
    skills: ["Python", "Machine Learning", "Statistics", "Pandas", "NumPy", "Data Visualization", "SQL", "Deep Learning"],
  },
  {
    job_role: "Machine Learning Engineer",
    skills: ["Python", "TensorFlow", "PyTorch", "Machine Learning", "Data Processing", "Model Deployment", "Docker", "MLOps"],
  },
  {
    job_role: "DevOps Engineer",
    skills: ["Linux", "Docker", "Kubernetes", "CI/CD", "AWS", "Terraform", "Monitoring", "Shell Scripting"],
  },
  {
    job_role: "Mobile App Developer",
    skills: ["Java", "Kotlin", "Flutter", "React Native", "Mobile UI Design", "REST APIs", "Firebase", "Git"],
  },
  {
    job_role: "UI/UX Designer",
    skills: ["Figma", "Adobe XD", "User Research", "Wireframing", "Prototyping", "Interaction Design", "Usability Testing"],
  },
  {
    job_role: "Cybersecurity Analyst",
    skills: ["Network Security", "Ethical Hacking", "Penetration Testing", "SIEM Tools", "Incident Response", "Cryptography"],
  },
  {
    job_role: "Cloud Engineer",
    skills: ["AWS", "Azure", "Google Cloud", "Docker", "Kubernetes", "Infrastructure as Code", "Networking"],
  },
  {
    job_role: "Data Analyst",
    skills: ["SQL", "Excel", "Python", "Power BI", "Tableau", "Data Cleaning", "Statistics"],
  },
  {
    job_role: "Game Developer",
    skills: ["C++", "C#", "Unity", "Unreal Engine", "Game Physics", "3D Graphics", "Game Design"],
  },
  {
    job_role: "Blockchain Developer",
    skills: ["Solidity", "Ethereum", "Smart Contracts", "Web3.js", "Cryptography", "Blockchain Architecture"],
  },
  {
    job_role: "AI Engineer",
    skills: ["Python", "Machine Learning", "Deep Learning", "TensorFlow", "PyTorch", "NLP", "Computer Vision"],
  },
  {
    job_role: "Database Administrator",
    skills: ["SQL", "Database Optimization", "Backup and Recovery", "PostgreSQL", "MySQL", "Performance Tuning"],
  },
  {
    job_role: "Product Manager",
    skills: ["Product Strategy", "Agile", "Market Research", "Roadmapping", "Stakeholder Communication"],
  },
  {
    job_role: "Digital Marketing Specialist",
    skills: ["SEO", "SEM", "Content Marketing", "Google Analytics", "Social Media Marketing", "Email Marketing"],
  },
  {
    job_role: "QA Engineer",
    skills: ["Manual Testing", "Automation Testing", "Selenium", "Test Cases", "Bug Tracking", "API Testing"],
  },
  {
    job_role: "Network Engineer",
    skills: ["Networking", "TCP/IP", "Routing", "Switching", "Network Security", "Cisco"],
  },
  {
    job_role: "Technical Support Engineer",
    skills: ["Troubleshooting", "Networking Basics", "Customer Support", "System Administration", "Documentation"],
  },
];
